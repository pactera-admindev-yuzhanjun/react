# Ariake Commerce Front-Admin

## Getting Started

`git clone https://github.com/fastretailing/fr-global-ec`

`npm install`

`npm start`

### disable CORS for Chrome Browser
Temporarily frontend-script calls Account-Platform directly.
To suppress CORS preflight request, use `--disable-web-security` flag when start Chrome Browser.

See Also:
- `https://qiita.com/growsic/items/a919a7e2a665557d9cf4`
- `https://qiita.com/mottox2/items/498bb31d67caa2d8a71f`

## Stack

* Using [React](https://facebook.github.io/react/) as component, Using [Redux](http://redux.js.org/) as state container.

## Project structure

```
- __tests__/
- build/
- config/
- public/
- src/
    - components/
        - common/
            - Label/
                - Label.js
            ・・・
        - [domain]/
            - [componentName].js
    - containers/
        - common/
            - something
                - [componentName].js
        - [domain]/
            - [componentName].js
    - modules/
        - common/
            - something
                - index.js ( reducers, action types, action creators, selectors )
        - [domain]/
            - [componentName].js ( reducers, action types, action creators )
    - constants/
    - index.css
    - index.js
    - App.js
```

1. `components` includes `stateless` components.
2. `containers` includes `statefull` components.
3. Each reducer will be loaded as asycn to reduce initial file size to load, so the initial redux state contains nothing.
4. modules folder includes `reducer`, `actionCreators` and `actions`. Please refer to [this article](https://qiita.com/oi5u/items/bf8a5ae2d0f9b128e6f5) and [this proposal](https://github.com/erikras/ducks-modular-redux)
5. helpers folder contains functions which is used in common.

## Refactoring Sprint1.2-apps during Sprint1.3-1.4
- Unit Testing
  - As Is:
    - Only few tests Implemented.
  - To Be:
    - Implements test codes.
- Coding Styles
  We're going to Apply rules based on "Google JavaScript Style Guide" (https://google.github.io/styleguide/javascriptguide.xml ).
  - As Is:
    - Adopted ESLint. But many Code does not follow rules yet.
  - To Be:
    - Follow rules.
- Internationalization
  - As Is:
    - Internationalization policy and method is not specified. Literal is written directory  on sources in English.
  - To Be:
    - Internationalize literal in react-components.
- Use for libraries
  - As Is:
    - Way of use libraries is unified by developers. (moment, promise ..etc.)
  - To Be:
    - Review each other and unify ways.
- Application Configurations (e.g Platform Endpoints)
  - As Is:
    - Coded as const.
  - To Be:
    - Add configuration files.

## Refactoring Sprint1.1-apps during Sprint1.2
We need Refactoring on Demonstrated Sprint1.1 application.
- Reducer
  - As Is:
    - only for first Page(CustomerList) in `index.js`.
  - To Be:
    - divide js-file to `modules/` and use combineReducers

- Store
  - As Is:
    - only for first Page(CustomerList) in `index.js`.
  - To Be:
    - refacor store structure like:
    ```
    {
        [common states]
        customers : {
            [states]
        }
    }
    ```

- Screen transition
  - As Is:
    - Unimplemented.
  - To Be:
    - Implements with react-router.

- ~/index.js
  - As Is:
    - Calls first Page Component (CustomerList) in `index.js`.
  - To Be:
    - Calls app.js and choose component on app.js.

- Coding Styles
  - As Is:
    - Not so Unified.
  - To Be:
    - Standardize. (use ES-Lint)

- Unit Testing
  - As Is:
    - Unimplemented. (manual tested only)
  - To Be:
    - Implement test-code on Jest.
