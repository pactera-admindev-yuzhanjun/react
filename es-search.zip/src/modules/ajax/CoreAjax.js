import SuperAgent from "superagent";

export default class CoreAjax {

  async get(url, postData) {
    console.log("<CoreAjax> get");
    return new Promise((resolve, reject) => {
      SuperAgent.get(url)
        .set("Content-Type", "application/json")
        .set("Token", "this is my test token")
        .end((error, response) => {
          if (error) {
            console.log("<CoreAjax> get : NG");
            reject(response);
          }
          else {
            console.log("<CoreAjax> get : OK");
            resolve(response.body);
          }
        });
    });
  }

  async del(url, postData) {
    console.log("<CoreAjax> del");
    return new Promise((resolve, reject) => {
      SuperAgent.del(url)
        .set("Content-Type", "application/json")
        .end((error, response) => {
          if (error) {
            console.log("<CoreAjax> del : NG");
            reject(response);
          }
          else {
            console.log("<CoreAjax> del : OK");
            resolve(response.body);
          }
        });
    });
  }

  async post(url, postData) {
    console.log("<CoreAjax> post");
    return new Promise((resolve, reject) => {
      SuperAgent.post(url)
        .set("Content-Type", "application/json")
        .send(postData)
        .end((error, response) => {
          if (error){
            console.log("<CoreAjax> post : NG");
            reject(response);
          }
          else {
            console.log("<CoreAjax> post : OK");
            resolve(response.body);
          }
        });
    });
  }

  async put(url, postData) {
    console.log("<CoreAjax> put");
    return new Promise((resolve, reject) => {
      SuperAgent.put(url)
        .set("Content-Type", "application/json")
        .send(postData)
        .end((error, response) => {
          if (error){
            console.log("<CoreAjax> post : NG");
            reject(response);
          }
          else {
            console.log("<CoreAjax> post : OK");
            resolve(response.body);
          }
        });
    });
  }

}
