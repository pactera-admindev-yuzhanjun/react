import CoreAjax from "./CoreAjax.js";

export default class Ajax {

  async get(url, bodyJson) {
    console.log("<Ajax> get");
    return new Promise((resolve, reject) => {
      const coreAjax = new CoreAjax();
      console.log("--------------------------");
      coreAjax.get(url, bodyJson)
        .then((response) => {
          console.log("<Ajax> - get : OK");
          resolve(response);
        })
        .catch((error) => {
          console.log("<Ajax> - get : NG");
          reject(error);
        });
    });
  }

  async del(url, bodyJson) {
    console.log("<Ajax> del");
    return new Promise((resolve, reject) => {
      const coreAjax = new CoreAjax();
      coreAjax.del(url, bodyJson)
        .then((response) => {
          console.log("<Ajax> - del : OK");
          resolve(response);
        })
        .catch((error) => {
          console.log("<Ajax> - del : NG");
          reject(error);
        });
    });
  }

  async post(url, bodyJson) {

    console.log("<Ajax> post JSON:" + bodyJson);

    return new Promise((resolve, reject) => {
      const coreAjax = new CoreAjax();
      coreAjax.post(url, bodyJson)
        .then((response) => {
          console.log("<Ajax> - post : OK");
          resolve(response);
        })
        .catch((error) => {
          console.log("<Ajax> - post : NG");
          reject(error);
        });
    });
  }

  async put(url, bodyJson) {

    console.log("<Ajax> post put:" + bodyJson);

    return new Promise((resolve, reject) => {
      const coreAjax = new CoreAjax();
      coreAjax.put(url, bodyJson)
        .then((response) => {
          console.log("<Ajax> - put : OK");
          resolve(response);
        })
        .catch((error) => {
          console.log("<Ajax> - put : NG");
          reject(error);
        });
    });
  }
}
