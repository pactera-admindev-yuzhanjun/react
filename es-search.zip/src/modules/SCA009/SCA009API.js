import Ajax from "../ajax/Ajax.js";

export default class SCA009API {

  async getAllIndexes(param) {
    console.log("SCA009API getAllIndexes");
    return new Promise((resolve, reject) => {
      const ajax = new Ajax();
      const url = "/es_search/_cat/indices?format=json";
      ajax.get(url, param)
        .then((response) => {
          console.log("SCA009API getAllIndexes OK");
          resolve(response);
        })
        .catch((error) => {
          console.log("SCA009API getAllIndexes NG");
          reject(error);
        });
    });
  };

  async getIndexSettings(param) {
    console.log("SCA009API getIndexSettings");
    return new Promise((resolve, reject) => {
      const ajax = new Ajax();
      const url = "/es_search/" + param.index + "/" + param.action;
      ajax.get(url, param)
        .then((response) => {
          console.log("SCA009API getIndexSettings OK");
          resolve(response);
        })
        .catch((error) => {
          console.log("SCA009API getIndexSettings NG");
          reject(error);
        });
    });
  }


  async getIndexMappings(param) {
    console.log("SCA009API getIndexMappings");
    return new Promise((resolve, reject) => {
      const ajax = new Ajax();
      const url = "/es_search/" + param.index + "/" + param.action;
      ajax.get(url, param)
        .then((response) => {
          console.log("SCA009API getIndexMappings OK");
          resolve(response);
        })
        .catch((error) => {
          console.log("SCA009API getIndexMappings NG");
          reject(error);
        });
    });
  }

  async openIndex(param) {
    console.log("SCA009API openIndex");
    return new Promise((resolve, reject) => {
      const ajax = new Ajax();
      const url = "/es_search/" + param.index + "/" + param.action;
      ajax.post(url, param)
        .then((response) => {
          console.log("SCA009API openIndex OK");
          resolve(response);
        })
        .catch((error) => {
          console.log("SCA009API openIndex NG");
          reject(error);
        });
    });
  }

  async closeIndex(param) {
    console.log("SCA009API closeIndex");
    return new Promise((resolve, reject) => {
      const ajax = new Ajax();
      const url = "/es_search/" + param.index + "/" + param.action;
      ajax.post(url, param)
        .then((response) => {
          console.log("SCA009API closeIndex OK");
          resolve(response);
        })
        .catch((error) => {
          console.log("SCA009API closeIndex NG");
          reject(error);
        });
    });
  }
  async optimizeIndex(param) {
    console.log("SCA009API optimizeIndex");
    return new Promise((resolve, reject) => {
      const ajax = new Ajax();
      const url = "/es_search/" + param.index + "/" + param.action;
      ajax.post(url, param)
        .then((response) => {
          console.log("SCA009API optimizeIndex OK");
          resolve(response);
        })
        .catch((error) => {
          console.log("SCA009API optimizeIndex NG");
          reject(error);
        });
    });
  }

  async delIndex(param) {
    console.log("SCA009API delIndex");
    return new Promise((resolve, reject) => {
      const ajax = new Ajax();
      const url = "/es_search/" + param.index;
      ajax.del(url, param.data)
        .then((response) => {
          console.log("SCA009API delIndex OK");
          resolve(response);
        })
        .catch((error) => {
          console.log("SCA009API delIndex NG");
          reject(error);
        });
    });
  }

  async putIndex(param) {
    console.log("SCA009API putIndex");
    return new Promise((resolve, reject) => {
      const ajax = new Ajax();
      const url = "/es_search/" + param.index;
      ajax.put(url, param.data)
        .then((response) => {
          console.log("SCA009API putIndex OK");
          resolve(response);
        })
        .catch((error) => {
          console.log("SCA009API putIndex NG");
          reject(error);
        });
    });
  }

  async testUploadData(param) {
    console.log("SCA009API testUploadData");
    return new Promise((resolve, reject) => {
      const ajax = new Ajax();
      const url = "/es_search/aaaaaaaaaaa";
      ajax.post(url, param)
        .then((response) => {
          console.log("SCA009API testUploadData OK");
          resolve(response);
        })
        .catch((error) => {
          console.log("SCA009API testUploadData NG");
          reject(error);
        });
    });
  }
}
