import React from "react";
import { BrowserRouter, Route, Link } from "react-router-dom";
import AppBar from "material-ui/AppBar";
import Drawer from "material-ui/Drawer";
import MenuItem from "material-ui/MenuItem";
import FontIcon from 'material-ui/FontIcon';
import Home from "../containers/home/home";
import SCA008 from "../containers/SCA008/SCA008";
import SCA009 from "../containers/SCA009/SCA009";

//const history = process.env.NODE_ENV !== "production" ? browserHistory : hashHistory;
export default class AppRoute extends React.Component {
  constructor(props) {
    super(props);
    this.state = {open: false};
  }
  handleToggle = () => {
    this.setState({open: !this.state.open})
  };
  render() {
    return (
      <BrowserRouter>
        <div>
          <AppBar title="Elasticsearch" onLeftIconButtonClick={this.handleToggle}/>
          <Drawer open={this.state.open}>
            <MenuItem
              style={{
                lineHeight: "64px",
                height: "64px",
                backgroundColor: "rgb(0, 188, 212)",
                color: "#FFF"
              }}
              leftIcon={
                <FontIcon className="material-icons" style={{color: "#FFF", fontSize: "36px"}} onClick={this.handleToggle}>close</FontIcon>
              }
            />
            <Link to="/">
              <MenuItem
                primaryText="HOME"
                rightIcon={
                  <FontIcon className="material-icons">home</FontIcon>
                }
              />
            </Link>
            <Link to="/SCA008">
              <MenuItem
                primaryText="SCA008"
                rightIcon={
                  <FontIcon className="material-icons">settings</FontIcon>
                }
              />
            </Link>
            <Link to="/SCA009">
              <MenuItem
                primaryText="SCA009"
                rightIcon={
                  <FontIcon className="material-icons">settings</FontIcon>
                }
              />
            </Link>
          </Drawer>
          <Route exact path="/" component={Home}/>
          <Route path="/SCA008" component={SCA008}/>
          <Route path="/SCA009" component={SCA009}/>
        </div>
      </BrowserRouter>
    );
  }
}