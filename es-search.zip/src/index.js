import React from "react";
import { render } from "react-dom";
import { Provider } from "react-redux";
import lightBaseTheme from "material-ui/styles/baseThemes/lightBaseTheme";
import getMuiTheme from "material-ui/styles/getMuiTheme";
import MuiThemeProvider from "material-ui/styles/MuiThemeProvider";
import AppRoute from "./router/route";
import store from "./redux/store/store";

import "./style/common.scss";

render(
  <Provider store={store}>
    <MuiThemeProvider muiTheme={getMuiTheme(lightBaseTheme)}>
      <AppRoute/>
    </MuiThemeProvider>
  </Provider>,
  document.getElementById("app")
);
