import SCA009API from "../../modules/SCA009/SCA009API";
import SCA009Constants from "../../constants/SCA009Constants.js";

export function changeSearchCondition(data) {
  return (dispatch) => {
    dispatch({
      type: SCA009Constants.CHANGE_SEARCH_CONDITION,
      id: data.id,
      value: data.value
    });
  };
}

export function getAllIndexes(data, callBackFn = () => {}) {
  return (dispatch) => {
    console.log("SCA009Actions: call SCA009API");
    const sac009Api = new SCA009API();
    sac009Api.getAllIndexes(data, callBackFn)
      .then((response) => {
        console.log("SCA009Actions: SCA009API getAllIndexes : OK");
        dispatch({
          type: SCA009Constants.GET_ALL_INDEXES,
          messages: ["SCA009API getAllIndexes : OK"],
          data: response
        });
        callBackFn();
      })
      .catch((error) => {
        console.log("SCA009Actions: SCA009API getAllIndexes : NG");
        dispatch({
          type: SCA009Constants.GET_ALL_INDEXES,
          messages: ["SCA009API getAllIndexes : NG"],
          data: []
        });
      });
  };
}

export function getIndexSettings(data, callBackFn = () => {}) {
  return (dispatch) => {
    console.log("SCA009Actions: call SCA009API");
    const sac009Api = new SCA009API();
    sac009Api.getIndexSettings(data, callBackFn)
      .then((response) => {
        console.log("SCA009Actions: SCA009API getIndexSettings : OK");
        dispatch({
          type: SCA009Constants.GET_INDEX_SETTINGS,
          messages: ["SCA009API getIndexSettings : OK"],
          data: response
        });
        callBackFn();
      })
      .catch((error) => {
        console.log("SCA009Actions: SCA009API getIndexSettings : NG");
        dispatch({
          type: SCA009Constants.GET_INDEX_SETTINGS,
          messages: ["SCA009API getIndexSettings : NG"],
          data: []
        });
      });
  };
}

export function getIndexMappings(data, callBackFn = () => {}) {
  return (dispatch) => {
    console.log("SCA009Actions: call SCA009API");
    const sac009Api = new SCA009API();
    sac009Api.getIndexMappings(data, callBackFn)
      .then((response) => {
        console.log("SCA009Actions: SCA009API getIndexMappings : OK");
        dispatch({
          type: SCA009Constants.GET_INDEX_MAPPINGS,
          messages: ["SCA009API getIndexMappings : OK"],
          data: response
        });
        callBackFn();
      })
      .catch((error) => {
        console.log("SCA009Actions: SCA009API getIndexMappings : NG");
        dispatch({
          type: SCA009Constants.GET_INDEX_MAPPINGS,
          messages: ["SCA009API getIndexMappings : NG"],
          data: []
        });
      });
  };
}

export function openIndex(data, callBackFn = () => {}) {
  return (dispatch) => {
    console.log("SCA009Actions: call SCA009API");
    const sac009Api = new SCA009API();
    sac009Api.openIndex(data, callBackFn)
      .then((response) => {
        console.log("SCA009Actions: SCA009API openIndex : OK");
        dispatch({
          type: SCA009Constants.OPEN_INDEX,
          messages: ["SCA009API openIndex : OK"],
          data: response
        });
        callBackFn();
      })
      .catch((error) => {
        console.log("SCA009Actions: SCA009API openIndex : NG");
        dispatch({
          type: SCA009Constants.OPEN_INDEX,
          messages: ["SCA009API openIndex : NG"],
          data: []
        });
      });
  };
}

export function closeIndex(data, callBackFn = () => {}) {
  return (dispatch) => {
    console.log("SCA009Actions: call SCA009API");
    const sac009Api = new SCA009API();
    sac009Api.closeIndex(data, callBackFn)
      .then((response) => {
        console.log("SCA009Actions: SCA009API closeIndex : OK");
        dispatch({
          type: SCA009Constants.CLOSE_INDEX,
          messages: ["SCA009API closeIndex : OK"],
          data: response
        });
        callBackFn();
      })
      .catch((error) => {
        console.log("SCA009Actions: SCA009API closeIndex : NG");
        dispatch({
          type: SCA009Constants.CLOSE_INDEX,
          messages: ["SCA009API closeIndex : NG"],
          data: []
        });
      });
  };
}

export function optimizeIndex(data, callBackFn = () => {}) {
  return (dispatch) => {
    console.log("SCA009Actions: call SCA009API");
    const sac009Api = new SCA009API();
    sac009Api.optimizeIndex(data, callBackFn)
      .then((response) => {
        console.log("SCA009Actions: SCA009API optimizeIndex : OK");
        dispatch({
          type: SCA009Constants.OPTIMIZE_INDEX,
          messages: ["SCA009API optimizeIndex : OK"],
          data: response
        });
        callBackFn();
      })
      .catch((error) => {
        console.log("SCA009Actions: SCA009API optimizeIndex : NG");
        dispatch({
          type: SCA009Constants.OPTIMIZE_INDEX,
          messages: ["SCA009API optimizeIndex : NG"],
          data: []
        });
      });
  };
}

export function delIndex(data, callBackFn = () => {}) {
  return (dispatch) => {
    console.log("SCA009Actions: call SCA009API");
    const sac009Api = new SCA009API();
    sac009Api.delIndex(data, callBackFn)
      .then((response) => {
        console.log("SCA009Actions: SCA009API delIndex : OK");
        dispatch({
          type: SCA009Constants.DEL_INDEX,
          messages: ["SCA009API delIndex : OK"],
          data: response
        });
        callBackFn();
      })
      .catch((error) => {
        console.log("SCA009Actions: SCA009API delIndex : NG");
        dispatch({
          type: SCA009Constants.DEL_INDEX,
          messages: ["SCA009API delIndex : NG"],
          data: []
        });
      });
  };
}

export function putIndex(data, callBackFn = () => {}) {
  return (dispatch) => {
    console.log("SCA009Actions: call SCA009API");
    const sac009Api = new SCA009API();
    sac009Api.putIndex(data, callBackFn)
      .then((response) => {
        console.log("SCA009Actions: SCA009API putIndex : OK");
        dispatch({
          type: SCA009Constants.PUT_INDEX,
          messages: ["SCA009API putIndex : OK"],
          data: response
        });
        callBackFn();
      })
      .catch((error) => {
        console.log("SCA009Actions: SCA009API putIndex : NG");
        dispatch({
          type: SCA009Constants.PUT_INDEX,
          messages: ["SCA009API putIndex : NG"],
          data: []
        });
      });
  };
}


export function testUploadData(data, callBackFn = () => {}) {
  return (dispatch) => {
    console.log("SCA009Actions: call SCA009API");
    const sac009Api = new SCA009API();
    sac009Api.testUploadData(data, callBackFn)
      .then((response) => {
        console.log("SCA009Actions: SCA009API testUploadData : OK");
        dispatch({
          type: SCA009Constants.PUT_INDEX,
          messages: ["SCA009API testUploadData : OK"],
          data: response
        });
        callBackFn();
      })
      .catch((error) => {
        console.log("SCA009Actions: SCA009API testUploadData : NG");
        dispatch({
          type: SCA009Constants.PUT_INDEX,
          messages: ["SCA009API testUplostData : NG"],
          data: []
        });
      });
  };
}
