import { combineReducers as CombineReducers } from "redux";
import SCA009 from "./SCA009Reducers";

export default CombineReducers({
  SCA009,
});
