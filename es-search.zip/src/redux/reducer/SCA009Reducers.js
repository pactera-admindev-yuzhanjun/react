import SCA009Constants from "../../constants/SCA009Constants";

let initializeSCA009 = {
  // searchCondition
  searchCondition: { },
  // searchResult
  searchResult: {
    indexesList: [],
    settings: {},
    mappings: {}
  },
  warningMessages: [],
  informationMessages: [],
};

export default function SCA009(state = initializeSCA009, action) {
  const newState = Object.assign({}, state);

  switch (action.type) {
    case SCA009Constants.GET_ALL_INDEXES:
      console.log("SCA009Constants.GET_ALL_INDEXES");
      newState.searchResult.indexesList = action.data;
      newState.messages = action.messages;
      return newState;

    case SCA009Constants.GET_INDEX_SETTINGS:
      console.log("SCA009Constants.GET_INDEX_SETTINGS");
      newState.searchResult.settings = action.data;
      newState.messages = action.messages;

      return newState;

    case SCA009Constants.GET_INDEX_MAPPINGS:
      console.log("SCA009Constants.GET_INDEX_MAPPINGS");
      newState.searchResult.mappings = action.data;
      newState.messages = action.messages;

      return newState;

    case SCA009Constants.OPEN_INDEX:
      console.log("SCA009Constants.OPEN_INDEX");
      newState.searchResult.indexStatus = action.data;
      newState.messages = action.messages;

      return newState;

    case SCA009Constants.CLOSE_INDEX:
      console.log("SCA009Constants.CLOSE_INDEX");
      newState.searchResult.indexStatus = action.data;
      newState.messages = action.messages;

      return newState;

    case SCA009Constants.OPTIMIZE_INDEX:
      console.log("SCA009Constants.OPTIMIZE_INDEX");
      newState.searchResult.indexStatus = action.data;
      newState.messages = action.messages;

      return newState;

    default:
      return state;
  }
}
