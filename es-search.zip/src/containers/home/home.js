import React from "react";
import { connect } from "react-redux";
import { is, fromJS } from "immutable";
import { bindActionCreators } from "redux";
import AceEditor from "react-ace";
import "brace/mode/text";
import "brace/mode/yaml";
import "brace/mode/json";
import "brace/theme/monokai";
import "brace/ext/language_tools";
import DatePicker from "material-ui/DatePicker";
import TextField from "material-ui/TextField";
import RaisedButton from "material-ui/RaisedButton";
import * as SCA009Actions from "../../redux/action/SCA009Actions";

class Home extends React.Component {
  constructor (props) {
    super(props);
    this.state = {
      drag: false,
      offsetX: 16,
      maxWidth: 0,
      minWidth: 0,
      index: "",
      content: "",
      msg: []
    }
  };

  handleChangeContent = (val) => {
    this.setState({
      content: val
    })
  };

  handleChangeIndex = (e, val) => {
    this.setState({
      index: val
    })
  };

  handleValidate = (val) => {
    this.setState({
      msg: val
    })
  };

  moveStart = (e) => {
    if (e.srcElement === this.refs["editor_resize"]) {
      this.setState({
        drag: true
      });
    } else {
      this.setState({
        drag: false
      });
    }
  };

  moveIng = (e) => {
    if (this.state.drag) {
      let x = e.clientX - this.state.offsetX;
      if (x > this.state.maxWidth-this.state.offsetX *1.5) {
        x = this.state.maxWidth - (this.state.offsetX * 2) - 3;
      }
      if (x < this.state.minWidth) {
        x = this.state.minWidth;
      }
      this.refs["editor_input"].style.width = x + "px";
    }
  };

  moveEnd = (e) => {
    this.setState({
      drag: false
    });
  };

  formatData = () => {
    this.setState({
      content: JSON.stringify(JSON.parse(this.state.content), null, "\t")
    })
  };

  putIndex = () => {
    let index = this.state.index;
    let content = this.state.content ? JSON.parse(this.state.content) : "";
    if (index == "") {
      alert("index is empty");
      return false;
    }
    const postData = {
      index: index,
      data: content
    }
    this.props.putIndex(postData);
  };

  testUploadData = () => {
    let formData = new FormData(this.refs["uploadForm"]);
    this.props.testUploadData(formData);
  };

  delIndex = () => {
    let index = this.state.index;
    let content = this.state.content ? JSON.parse(this.state.content) : "";
    if (index == "") {
      alert("index is empty");
      return false;
    }
    const postData = {
      index: index,
      data: content
    }
    this.props.delIndex(postData);
  };

  onWindowResize = () => {
    let maxWidth = this.refs["editor_container"].clientWidth;
    this.state.maxWidth = maxWidth;
    let x = this.refs["editor_input"].clientWidth
    if (x > maxWidth-this.state.offsetX *1.5) {
      x = maxWidth - (this.state.offsetX * 2) - 3;
    }
    this.refs["editor_input"].style.width = x + "px";
  };

  componentDidMount() {
    if (document.addEventListener){
      window.addEventListener('resize', this.onWindowResize)
      this.refs["dev-tools-container"].addEventListener("mousedown", (e)=>{this.moveStart(e);}, false);
      this.refs["dev-tools-container"].addEventListener("mousemove", (e)=>{this.moveIng(e);}, false);
      this.refs["dev-tools-container"].addEventListener("mouseup", (e)=>{this.moveEnd(e);}, false);
    } else {
      window.attachEvent('onresize', this.onWindowResize)
      this.refs["dev-tools-container"].attachEvent("onmousedown", (e)=>{this.moveStart(e);}, false);
      this.refs["dev-tools-container"].attachEvent("onmousemove", (e)=>{this.moveIng(e);}, false);
      this.refs["dev-tools-container"].attachEvent("onmouseup", (e)=>{this.moveEnd(e);}, false);
    }
    let maxWidth = this.refs["editor_container"].clientWidth;
    this.state.maxWidth = maxWidth;
  };

  componentWillUnmount() {
    window.removeEventListener('resize', this.onWindowResize)
  };

  render() {
    console.log("Home-----render");
    const command = [{
      name: "save",
      bindKey: {
        mac: "Command-F",
        win: "Ctrl-F"
      },
      exec: function(){
        //saveFile();
        alert("FFFFFFFFFFF");
      }
    }]
    return(
      <div>
        <div className="dev-tools-container" ref="dev-tools-container">
          <div id="editor_container" ref="editor_container">
            <div id="editor_input" ref="editor_input">
              <AceEditor
                mode="json"
                theme="monokai"
                name="input"
                onChange={this.handleChangeContent}
                value={this.state.content}
                width="100%"
                showPrintMargin={false}
                commands={command}
                editorProps={{
                  $blockScrolling: false,
                }}
                onValidate={this.handleValidate}
              />
            </div>
            <div id="editor_resize" ref="editor_resize">︙</div>
            <div id="editor_output">
              <AceEditor
                mode="json"
                theme="monokai"
                name="output"
                width="100%"
                showPrintMargin={false}
                editorProps={{
                  $blockScrolling: false,
                }}
              />
            </div>
          </div>

        </div>
        <form ref="uploadForm" id= "uploadForm">
          <input type="text" name="test" ref="test" id="test"/>
          <input type="file" name="upload" ref="upload" id="upload"/><br/>
          <RaisedButton onClick={this.testUploadData.bind(this)}>upload</RaisedButton><br/><br/>
        </form>
        index name:<TextField id="index" onChange={this.handleChangeIndex} underlineShow={false} inputStyle={{
          border: "1px solid red"
        }}/><br/><br/>
        <RaisedButton onClick={this.formatData} disabled={this.state.content == "" || this.state.msg.length == 1}>formatData</RaisedButton><br/><br/>
        <RaisedButton onClick={this.putIndex} disabled={this.state.msg.length == 1}>putIndex</RaisedButton><br/><br/>
        <RaisedButton onClick={this.delIndex} disabled={this.state.msg.length == 1}>delIndex</RaisedButton><br/><br/>
        <DatePicker hintText="Portrait Dialog" />
        <DatePicker hintText="Landscape Dialog" mode="landscape" />
        <DatePicker hintText="Dialog Disabled" disabled={true} />
        <DatePicker hintText="Open to Year" openToYearSelection={true} />
      </div>
    );
  };
}


function mapStateToProps(state) {
  return state;
}

function mapDispatchToProps(dispatch) {
  return {
    ...bindActionCreators(SCA009Actions, dispatch)
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(Home);
