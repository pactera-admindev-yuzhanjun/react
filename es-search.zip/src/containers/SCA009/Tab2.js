import React from "react";
import { connect } from "react-redux";

class Tab2 extends React.Component {
  constructor(props) {
    super(props);
  }


  render() {
    return (
      <div>
        <button></button>
        this is tab2 page
      </div>
    );
  }
}

export default connect((state) => state)(Tab2);
