import React from "react";
import configureMockStore from 'redux-mock-store';
import {mount, shallow} from "enzyme";
import SCA009 from "../SCA009";
import Tab1 from "../Tab1";
import Tab2 from "../Tab2";
import Tab3 from "../Tab3";
import Tab4 from "../Tab4";

let store = configureMockStore()({});

const childProps = {
  store: store,
  SCA009: {
    messages: [],
    searchResult: []
  }
};

function setup() {
  const tab1 = mount(<Tab1 {...childProps}/>);
  const tab2 = mount(<Tab2 {...childProps}/>);
  const tab3 = mount(<Tab3 {...childProps}/>);
  const tab4 = mount(<Tab4 {...childProps}/>);

  const parentProps = {
    store: store,
    SCA009: {
      messages: [],
      searchResult: []
    },
    tab1,
    tab2,
    tab3,
    tab4
  };
  const wrapper = shallow(<SCA009 {...parentProps}/>);

  return wrapper
}

describe("container tests", () => {
  it("should return no error", () => {
    const enzymeWrapper = setup();
    expect(enzymeWrapper.exists()).toBe(true);
  });
});