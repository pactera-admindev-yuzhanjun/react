import 'babel-polyfill';
import React from "react";
import { connect } from "react-redux";
import { is, fromJS } from "immutable";
import { bindActionCreators } from "redux";
import AceEditor from "react-ace";
import "brace/mode/json";
import "brace/theme/monokai";
import Popover, {PopoverAnimationVertical} from "material-ui/Popover";
import Menu from "material-ui/Menu";
import MenuItem from "material-ui/MenuItem";
import RemoveRedEye from "material-ui/svg-icons/image/remove-red-eye";
import { Table, TableBody, TableHeader, TableHeaderColumn, TableRow, TableRowColumn } from "material-ui/Table";
import Dialog from "material-ui/Dialog";
import FlatButton from "material-ui/FlatButton";
import * as SCA009Actions from "../../redux/action/SCA009Actions";


class Tab1 extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      openMenu: false,
      index: "",
      openDialog: false,
      content: "",
      indexStatus:"",
      loaded: false
    };
  }

  handleOpenMenu = (index, status, event) => {
    // This prevents ghost click.
    this.setState({
      openMenu: true,
      index: index,
      indexStatus: status,
      anchorEl: event.currentTarget
    });
    event.preventDefault();
  };

  handleCloseMenu = () => {
    this.setState({
      openMenu: false,
    });
  };

  handleOpenDialog = () => {
    this.setState({openDialog: true});
  };

  handleCloseDialog = () => {
    this.setState({openDialog: false});
  };

  getAllIndexes = () => {
    const postData = {
      "query": {
        "prefix": {
          "index": "sam-"
        }
      }
    }
    this.props.getAllIndexes(postData);
  };

  showSettings = () => {
    const postData = {
      index:this.state.index,
      action: "_settings"
    }
    this.props.getIndexSettings(postData);
    this.setState({
      content: "settings"
    })
    this.handleCloseMenu();
    this.handleOpenDialog();
  };

  showMappings = () => {
    const postData = {
      index:this.state.index,
      action: "_mappings"
    }
    this.props.getIndexMappings(postData);
    this.setState({
      content: "mappings"
    })
    this.handleCloseMenu();
    this.handleOpenDialog();
  };

  openIndex = () => {
    const postData = {
      index:this.state.index,
      action: "_open"
    }
    this.props.openIndex(postData, this.getAllIndexes);
    this.handleCloseMenu();
  };

  closeIndex = () => {
    const postData = {
      index:this.state.index,
      action: "_close"
    }
    this.props.closeIndex(postData, this.getAllIndexes);
    this.handleCloseMenu();
  };

  optimizeIndex = () => {
    const postData = {
      index:this.state.index,
      action: "_optimize"
    }
    this.props.optimizeIndex(postData);
    this.handleCloseMenu();
  };

  componentWillMount(){
    this.getAllIndexes();
  };

  render() {
    const showCheckboxes = false;
    const stripedRows = true;
    const showRowHover = true;
    const rows = this.props.SCA009.searchResult.indexesList;
    let msg = "";
    let jsonData = "";
    if (this.state.content == "settings") {
      msg = JSON.stringify(this.props.SCA009.searchResult.settings, null, "\t");
      jsonData = this.props.SCA009.searchResult.settings;
      Object.entries(jsonData).map(([key, val]) => {
        console.log(key);
        console.log(val)
      })
    }
    if (this.state.content == "mappings") {
      msg = JSON.stringify(this.props.SCA009.searchResult.mappings, null, "\t");
    }
    return (
      <div>
        <Table>
          <TableHeader displaySelectAll={showCheckboxes} adjustForCheckbox={showCheckboxes}>
            <TableRow style={{background:"#526ca5"}}>
              <TableHeaderColumn style={{color:"#ffffff"}}>Index</TableHeaderColumn>
              <TableHeaderColumn style={{color:"#ffffff"}}>number of primary shards</TableHeaderColumn>
              <TableHeaderColumn style={{color:"#ffffff"}}>number of replica shards</TableHeaderColumn>
              <TableHeaderColumn style={{color:"#ffffff"}}>number of docs</TableHeaderColumn>
              <TableHeaderColumn style={{color:"#ffffff"}}>number of deleted docs</TableHeaderColumn>
              <TableHeaderColumn style={{color:"#ffffff"}}>size</TableHeaderColumn>
              <TableHeaderColumn style={{color:"#ffffff"}}>aliases</TableHeaderColumn>
            </TableRow>
          </TableHeader>
          <TableBody displayRowCheckbox={showCheckboxes} stripedRows={stripedRows} showRowHover={showRowHover}>
            {
              rows.map((val, key) => {
                return(
                  <TableRow key={key}>
                    <TableRowColumn><a href="javascript:void(0)" onClick={this.handleOpenMenu.bind(this, val["index"], val["status"])}>{val["index"]}</a></TableRowColumn>
                    <TableRowColumn>{val["pri"]}</TableRowColumn>
                    <TableRowColumn>{val["rep"]}</TableRowColumn>
                    <TableRowColumn>{val["docs.count"]}</TableRowColumn>
                    <TableRowColumn>{val["docs.deleted"]}</TableRowColumn>
                    <TableRowColumn>{val["store.size"]}</TableRowColumn>
                    <TableRowColumn>{val["status"]}</TableRowColumn>
                  </TableRow>
                );
              })
            }
          </TableBody>
        </Table>
        <Popover
          open={this.state.openMenu}
          anchorEl={this.state.anchorEl}
          anchorOrigin={{horizontal: "left", vertical: "top"}}
          targetOrigin={{horizontal: "left", vertical: "top"}}
          onRequestClose={this.handleCloseMenu}
          animation={PopoverAnimationVertical}
        >
          <Menu>
            <MenuItem primaryText="show settings" leftIcon={<RemoveRedEye />} onClick={this.showSettings}/>
            <MenuItem primaryText="show mappings" leftIcon={<RemoveRedEye />} onClick={this.showMappings}/>
            {(() => {
              if (this.state.indexStatus==="open") {
                return(
                  <MenuItem primaryText="close index" leftIcon={<RemoveRedEye />} onClick={this.closeIndex} />
                );
              } else {
                return(
                  <MenuItem primaryText="open index" leftIcon={<RemoveRedEye />} onClick={this.openIndex} />
                );
              }
            })()}
            <MenuItem primaryText="optimize index" leftIcon={<RemoveRedEye />} onClick={this.optimizeIndex} />
          </Menu>
        </Popover>
        <Dialog
          title="Dialog With Actions"
          actions={
            [
              <FlatButton
                label="CLOSE"
                primary={true}
                onClick={this.handleCloseDialog}
              />
            ]
          }
          modal={true}
          open={this.state.openDialog}
        >
          <AceEditor
            mode="json"
            theme="monokai"
            name="UNIQUE_ID_OF_DIV"
            width="100%"
            showPrintMargin={false}
            value={msg}
            editorProps={{$blockScrolling: true}}
          />
        </Dialog>
      </div>
    );
  }
}

function mapStateToProps(state) {
  return state;
}

function mapDispatchToProps(dispatch) {
  return {
    ...bindActionCreators(SCA009Actions, dispatch)
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(Tab1);
