import React from "react";
import { connect } from "react-redux";

class Tab4 extends React.Component {
  constructor(props) {
    super(props);
  }


  render() {
    return (
      <div>
        this is tab4 page
      </div>
    );
  }
}

export default connect((state) => state)(Tab4);
