import React from "react";
import { connect } from "react-redux";
import { Tabs, Tab } from "material-ui/Tabs";
import Tab1 from "./Tab1";
import Tab2 from "./Tab2";
import Tab3 from "./Tab3";
import Tab4 from "./Tab4";

class SCA009 extends React.Component {
  constructor(props) {
    super(props);
  }

  handleActive = (tab) => {
    alert(`A tab with this route property ${tab.props["data-route"]} was activated.`);
  }

  render() {
    console.log("SCA009-----render");
    return (
      <Tabs style={{marginTop:"1px"}}>
        <Tab label="indexes management">
            <Tab1/>
        </Tab>
        <Tab label="create index">
          <Tab2/>
        </Tab>
        <Tab label="indexe template">
          <Tab3/>
        </Tab>
        <Tab label="onActive" data-route="/home" onActive={this.handleActive}>
          <Tab4/>
        </Tab>
      </Tabs>
    );
  }
}

export default connect((state) => state)(SCA009);
