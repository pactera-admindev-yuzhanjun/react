export default class SCA009Constants {
  static get GET_ALL_INDEXES() { return "GET_ALL_INDEXES"; }
  static get GET_INDEX_SETTINGS() { return "GET_INDEX_SETTINGS"; }
  static get GET_INDEX_MAPPINGS() { return "GET_INDEX_MAPPINGS"; }
  static get OPEN_INDEX() { return "OPEN_INDEX"; }
  static get CLOSE_INDEX() { return "CLOSE_INDEX"; }
  static get DEL_INDEX() { return "DEL_INDEX"; }
  static get PUT_INDEX() { return "PUT_INDEX"; }
  static get OPTIMIZE_INDEX() { return "OPTIMIZE_INDEX"; }
}
